namespace $safeprojectname$.Support
{
	public class Score
	{
		public int Level = 1;
		public int Count = 0;
		public int Errors = 0;
		public int Points = 0;
	}
}
