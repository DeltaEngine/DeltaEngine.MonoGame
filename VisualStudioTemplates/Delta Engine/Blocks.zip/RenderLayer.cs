namespace $safeprojectname$
{
	public enum RenderLayer
	{
		Background,
		Foreground,
		Grid,
		FallingBrick,
		ZoomingBrick
	}
}