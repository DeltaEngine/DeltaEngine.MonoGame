namespace $safeprojectname$
{
	public class JewelBlocksContent : BlocksContent
	{
		public JewelBlocksContent() : base("JewelBlocks_")
		{
		}
	}
}