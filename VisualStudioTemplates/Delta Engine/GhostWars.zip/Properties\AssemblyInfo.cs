using System;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: CLSCompliant(true)]
[assembly: AssemblyDescription("Delta Engine Game $projectname$")]
[assembly: AssemblyTitle("$projectname$")]
[assembly: AssemblyCompany("Benjamin Nitschke")]
[assembly: AssemblyProduct("GhostWars")]
[assembly: AssemblyCopyright("Copyright � Benjamin Nitschke 2013")]
[assembly: ComVisible(false)]
[assembly: Guid("$guid1$")]
[assembly: AssemblyVersion("0.9.9.5")]
[assembly: AssemblyFileVersion("0.9.9.5")]
