namespace $safeprojectname$.Content
{
	public enum ComicStrips
	{
		ComicStripsStoryboardPanel1,
		ComicStripsStoryboardPanel2,
		ComicStripsStoryboardPanel3,
		ComicStripsStoryboardPanel4,
		ComicStripsStoryboardPanel5,
		ComicStripDragon,
		ComicStripPiggybank,
		ComicStripUnicorn,
		ComicStripBubble,
		IconMouseLeft,
		IconMouseRight,
		UnicornAttackMockup,
		ComicStripsDragonAttackMockup512
	}
}