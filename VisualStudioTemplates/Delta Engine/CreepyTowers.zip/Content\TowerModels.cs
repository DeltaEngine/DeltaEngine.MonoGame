namespace $safeprojectname$.Content
{
	public enum TowerModels
	{
		TowerAcidConeJanitorHigh,
		TowerFireCandlehulaHigh,
		TowerIceConeIceladyHigh,
		TowerImpactRangedKnightscalesHigh,
		TowerSliceConeKnifeblockHigh,
		TowerWaterRangedWatersprayHigh
	}
}