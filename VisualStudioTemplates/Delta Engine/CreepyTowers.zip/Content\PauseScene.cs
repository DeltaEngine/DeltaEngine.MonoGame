namespace $safeprojectname$.Content
{
	public enum PauseScene
	{
		ButtonHome,
		ButtonRestart,
		ButtonResume
	}
}
