namespace $safeprojectname$.Creeps
{
	public enum CreepType
	{
		Paper,
		Cloth,
		Wood,
		Plastic,
		Sand,
		Glass,
		Iron
	}
}