namespace $safeprojectname$.Content
{
	public enum Effects
	{
		EffectsWaterRangedTrans,
		SmokecloudEffect
	}
}