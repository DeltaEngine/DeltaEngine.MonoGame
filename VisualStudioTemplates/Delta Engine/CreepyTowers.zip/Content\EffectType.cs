namespace $safeprojectname$.Content
{
	public enum EffectType
	{
		Attack,
		Projectile,
		Hit,
		Death,
		Transform
	}
}