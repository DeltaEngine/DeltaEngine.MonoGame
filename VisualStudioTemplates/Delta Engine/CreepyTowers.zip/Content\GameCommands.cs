namespace $safeprojectname$.Content
{
	public enum GameCommands
	{
		MouseLeftButtonClick,
		MouseRightButtonClick,
		ViewPanning,
		ViewZooming,
		TurnViewRight,
		TurnViewLeft
	}
}
