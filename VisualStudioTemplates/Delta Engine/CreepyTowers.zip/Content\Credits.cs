namespace $safeprojectname$.Content
{
	public enum Credits
	{
		ButtonBack
	}
}
