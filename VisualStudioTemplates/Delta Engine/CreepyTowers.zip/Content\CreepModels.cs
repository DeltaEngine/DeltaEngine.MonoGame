namespace $safeprojectname$.Content
{
	public enum CreepModels
	{
		CreepCottonMummyHigh,
		CreepMetalTAxeHigh,
		CreepGlassHigh,
		CreepPaperPaperplaneHigh,
		CreepPlasticBottledogHigh,
		CreepSandSandyHigh,
		CreepWoodScarecrowHigh
	}
}