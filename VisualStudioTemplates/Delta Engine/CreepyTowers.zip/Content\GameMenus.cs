namespace $safeprojectname$.Content
{
	public enum GameMenus
	{
		SceneIntro,
		SceneMainMenu,
		SceneSettingsMenu,
		SceneCredits,
		SceneGameHud,
		SceneGamePaused,
		SceneChapterSuccess,
		SceneNightmare1,
		SceneAvatarSelection, 
		TowerSelectionPanel,
		SceneTutorial,
		SceneAvatarSuperVillain
	}
}