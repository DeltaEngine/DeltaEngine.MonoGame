namespace $safeprojectname$.Content
{
	public enum LevelMaps
	{
		N1C1ChildsRoomLevelInfo,
		N1C2ChildsRoomLevelInfo,
		N1C3BathroomLevelInfo,
		N1C7LivingRoomLevelInfo
	}
}
