using System;

namespace $safeprojectname$.Screens
{
	/*TODO
	/// <summary>
	/// The contents of this file are auto generated. Do not edit, Editor will overwrite this.
  /// </summary>
  public partial class CharacterMenu : BaseGameScreen
  {
    public Delta.Graphics.UserInterfaces.Controls.Button BackButton;
        
    public Delta.Graphics.UserInterfaces.Controls.Label TitleLabel;
        
    public Delta.Graphics.UserInterfaces.Controls.Button LeftButton;
        
    public Delta.Graphics.UserInterfaces.Controls.Button RightButton;
        
    public Delta.Graphics.UserInterfaces.Controls.Label RaceLabel;
        
    public Delta.Graphics.UserInterfaces.Controls.Label Feature2Label;
        
    public Delta.Graphics.UserInterfaces.Controls.Label Feature1Label;
        
    public Delta.Graphics.UserInterfaces.Controls.Label Feature3Label;
        
    public Delta.Graphics.UserInterfaces.Controls.Button YesButton;
        
    public Delta.Graphics.UserInterfaces.Controls.Image Image0;
        
    private void InitializeControls()
    {
        this.LoadUIScene("CharacterMenu");
        BackButton = this.FindUIControl<Button>("BackButton");
        TitleLabel = this.FindUIControl<Label>("TitleLabel");
        LeftButton = this.FindUIControl<Button>("LeftButton");
        RightButton = this.FindUIControl<Button>("RightButton");
        RaceLabel = this.FindUIControl<Label>("RaceLabel");
        Feature2Label = this.FindUIControl<Label>("Feature2Label");
        Feature1Label = this.FindUIControl<Label>("Feature1Label");
        Feature3Label = this.FindUIControl<Label>("Feature3Label");
        YesButton = this.FindUIControl<Button>("YesButton");
        Image0 = this.FindUIControl<Image>("Image0");
    }
  }
	 */
}
