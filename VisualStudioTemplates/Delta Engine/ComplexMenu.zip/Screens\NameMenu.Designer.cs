namespace $safeprojectname$.Screens
{
	/*TODO
	/// <summary>
	/// The contents of this file are auto generated. Do not edit, Editor will overwrite this.
	/// </summary>
		public partial class NameMenu : BaseGameScreen
		{
				
				public Delta.Graphics.UserInterfaces.Controls.TextBox NameTextbox;
				
				public Delta.Graphics.UserInterfaces.Controls.Button BackButton;
				
				public Delta.Graphics.UserInterfaces.Controls.Label TitleLabel;
				
				public Delta.Graphics.UserInterfaces.Controls.Label Description2Label;
				
				public Delta.Graphics.UserInterfaces.Controls.Label Description3Label;
				
				public Delta.Graphics.UserInterfaces.Controls.Label Description1Label;
				
				private void InitializeControls()
				{
						this.LoadUIScene("NameMenu");
						NameTextbox = this.FindUIControl<TextBox>("NameTextbox");
						BackButton = this.FindUIControl<Button>("BackButton");
						TitleLabel = this.FindUIControl<Label>("TitleLabel");
						Description2Label = this.FindUIControl<Label>("Description2Label");
						Description3Label = this.FindUIControl<Label>("Description3Label");
						Description1Label = this.FindUIControl<Label>("Description1Label");
				}
		}
	 */
}
