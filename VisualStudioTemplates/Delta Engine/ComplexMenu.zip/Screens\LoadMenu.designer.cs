namespace $safeprojectname$.Screens
{
	/*TODO
	/// <summary>
	/// The contents of this file are auto generated. Do not edit, Editor will overwrite this.
	/// </summary>
	public partial class LoadMenu : BaseGameScreen
	{ 
		public Delta.Graphics.UserInterfaces.Controls.Button TopLeftButton;
        
		public Delta.Graphics.UserInterfaces.Controls.Button TopRightButton;
        
		public Delta.Graphics.UserInterfaces.Controls.Button MiddleLeftButton;
        
		public Delta.Graphics.UserInterfaces.Controls.Button BackButton;
        
		public Delta.Graphics.UserInterfaces.Controls.Label TitleLabel;
        
		public Delta.Graphics.UserInterfaces.Controls.Button LeftBottomButton;
        
		public Delta.Graphics.UserInterfaces.Controls.Button MiddleRightButton;
        
		public Delta.Graphics.UserInterfaces.Controls.Button RightBottomButton;
        
		private void InitializeControls()
		{
				this.LoadUIScene("LoadMenu");
				TopLeftButton = this.FindUIControl<Button>("TopLeftButton");
				TopRightButton = this.FindUIControl<Button>("TopRightButton");
				MiddleLeftButton = this.FindUIControl<Button>("MiddleLeftButton");
				BackButton = this.FindUIControl<Button>("BackButton");
				TitleLabel = this.FindUIControl<Label>("TitleLabel");
				LeftBottomButton = this.FindUIControl<Button>("LeftBottomButton");
				MiddleRightButton = this.FindUIControl<Button>("MiddleRightButton");
				RightBottomButton = this.FindUIControl<Button>("RightBottomButton");
		}
	}
	 */
}
