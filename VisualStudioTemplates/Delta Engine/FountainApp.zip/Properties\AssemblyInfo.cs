using System;
using System.Reflection;
using System.Runtime.InteropServices;

[assembly: CLSCompliant(true)]
[assembly: AssemblyTitle("$projectname$")]
[assembly: AssemblyDescription("Delta Engine Game $projectname$")]
[assembly: AssemblyCompany("DeltaEngine")]
[assembly: AssemblyProduct("FountainApp")]
[assembly: AssemblyCopyright("Copyright � DeltaEngine 2013")]
[assembly: ComVisible(false)]
[assembly: Guid("$guid1$")]
[assembly: AssemblyVersion("0.9.9.5")]
[assembly: AssemblyFileVersion("0.9.9.5")]
