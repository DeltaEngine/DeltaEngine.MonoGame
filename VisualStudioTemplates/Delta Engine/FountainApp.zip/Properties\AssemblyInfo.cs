using System;
using System.Reflection;
using System.Runtime.InteropServices;

[assembly: CLSCompliant(true)]
[assembly: AssemblyTitle("$projectname$")]
[assembly: AssemblyDescription("Delta Engine Game $projectname$")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("DeltaEngine")]
[assembly: AssemblyProduct("FountainApp")]
[assembly: AssemblyCopyright("Copyright � DeltaEngine 2013")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: Guid("$guid1$")]
[assembly: AssemblyVersion("1.1")]
[assembly: AssemblyFileVersion("1.1")]
